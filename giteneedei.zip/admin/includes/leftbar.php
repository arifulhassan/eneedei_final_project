	<nav class="ts-sidebar">
			<ul class="ts-sidebar-menu">
			
				<li class="ts-label">Main</li>
				<li><a href="dashboard.php"><i class="fa fa-dashboard"></i> Dashboard</a></li>
			
<li><a href="#"><i class="fa fa-files-o"></i> Branch</a>
<ul>
<li><a href="create-brand.php">Create Branch</a></li>
<li><a href="manage-brands.php">Manage Branch</a></li>
</ul>
</li>

<li><a href="#"><i class="fa fa-sitemap"></i>Packages</a>
					<ul>
						<li><a href="post-avehical.php">Post Package</a></li>
						<li><a href="manage-vehicles.php">Manage Package</a></li>
					</ul>
				</li>

				<li><a href="#"><i class="fa fa-files-o"></i>Parcel</a>
<ul>
<li><a href="manage-bookings.php">Package Delivery</a></li>
<li><a href="ultra-booking.php">Ultra Delivery</a></li>
</ul>
</li>

				<!-- <li><a href="manage-bookings.php"><i class="fa fa-users"></i>Parcel</a></li> -->

				<li><a href="testimonials.php"><i class="fa fa-table"></i> Manage Feedback</a></li>
				<li><a href="manage-conactusquery.php"><i class="fa fa-desktop"></i> Manage Conatctus</a></li>
				<li><a href="reg-users.php"><i class="fa fa-users"></i>Users</a></li>
			<li><a href="manage-pages.php"><i class="fa fa-files-o"></i> Manage Pages</a></li>
			<li><a href="update-contactinfo.php"><i class="fa fa-files-o"></i>Contact</a></li>

			<li><a href="manage-subscribers.php"><i class="fa fa-table"></i>Subscribers</a></li>

			</ul>
		</nav>