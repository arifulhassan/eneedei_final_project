<?php 
// $con = mysqli_connect('localhost', 'root', '', 'ecs');

$con = mysqli_connect('localhost', 'eneedeic_signup', '123456', 'eneedeic_signup');

?>